const { DynamoDBClient, DeleteItemCommand } = require("@aws-sdk/client-dynamodb");

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1",
});

const tableName = 'Events';

const handler = async (event) => {
    try {
        console.log("Input event:", JSON.stringify(event, null, 2));

        // Handle CORS preflight request
        if (event.httpMethod === 'OPTIONS') {
            console.log("CORS preflight request");
            return {
                statusCode: 200,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "POST, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type",
                },
                body: JSON.stringify({ message: 'CORS preflight response' }),
            };
        }

        // Extract and parse the body
        let body = event.body;
        console.log("Raw body:", body);

        // If the body contains extra escaping, handle it here
        let parsedBody;
        try {
            parsedBody = JSON.parse(body);
            console.log("Parsed body:", parsedBody);
        } catch (err) {
            console.error("Error parsing body:", err);
            throw new Error('Error parsing request body');
        }

        // Extract eventId from the parsed body
        const { eventId } = JSON.parse(parsedBody.body || '{}');
        console.log("Extracted eventId:", eventId);

        if (!eventId) {
            throw new Error('Event ID is required');
        }

        // Delete the event from DynamoDB
        await deleteEvent(eventId);
        console.log("Event deleted successfully:", eventId);

        // Return success response with CORS headers
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: 'Event deleted successfully.' }),
        };
    } catch (error) {
        console.error("Error occurred:", error.message);
        console.error("Stack trace:", error.stack);

        // Return error with CORS headers
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: 'Error deleting event from DB', error: error.message }),
        };
    }
};

async function deleteEvent(eventId) {
    try {
        console.log("Deleting event from DynamoDB with eventId:", eventId);
        const params = {
            TableName: tableName,
            Key: {
                eventId: { S: eventId }
            }
        };
        await dynamoDBClient.send(new DeleteItemCommand(params));
        console.log("Successfully deleted event from DynamoDB");
    } catch (error) {
        console.error("Error deleting event from DynamoDB:", error.message);
        throw error;
    }
}

module.exports = { handler };
