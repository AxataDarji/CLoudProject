import { DynamoDBClient, DeleteItemCommand } from "@aws-sdk/client-dynamodb";

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1", // Change the region to match your DynamoDB region
});

const tableName = 'Events';

export const handler = async (event) => {
    try {
        console.log("Input is: ", event);
        
        // Handle CORS preflight request
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "DELETE, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type",
                },
                body: JSON.stringify({ message: 'CORS preflight response' }),
            };
        }

        // Extract the eventId from the event object or the body property
        const { eventId } = JSON.parse(event.body || '{}');
        
        if (!eventId) {
            throw new Error('Event ID is required');
        }

        // Delete the event from DynamoDB
        await deleteEvent(eventId);

        console.log("Event deleted successfully");

        // Return success response with CORS headers
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: 'Event deleted successfully.' }),
        };
    } catch (error) {
        console.error("Error occurred which is: ", error);
        // Return error with CORS headers
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: 'Error deleting event from DB', error: error.message }),
        };
    }
};

async function deleteEvent(eventId) {
    const params = {
        TableName: tableName,
        Key: {
            eventId: { S: eventId }
        }
    };
    await dynamoDBClient.send(new DeleteItemCommand(params));
}
