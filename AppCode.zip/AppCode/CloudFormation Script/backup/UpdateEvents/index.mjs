import { DynamoDBClient, UpdateItemCommand } from "@aws-sdk/client-dynamodb";

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1", // Change the region to match your DynamoDB region
});

const tableName = 'Events'; // Replace 'YourTableName' with your DynamoDB table name

export const handler = async (event) => {
    try {
        console.log("Input is: ", event);
        
        // Extract the eventId and updated event details from the event object
        const { eventId, updatedEvent } = event;
        
        // Update the event in DynamoDB
        await updateEvent(eventId, updatedEvent);

        console.log("Event updated successfully");

        // Return success response 
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Event updated successfully.' }),
        };
    } catch (error) {
        console.error("Error occurred which is: ", error);
        // Return error
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error updating event in DB', error: error.message }),
        };
    }
};

async function updateEvent(eventId, updatedEvent) {
    const params = {
        TableName: tableName,
        Key: {
            eventId: { S: eventId }
        },
        UpdateExpression: 'SET #date = :date, #time = :time, #description = :description',
        ExpressionAttributeNames: {
            '#date': 'date',
            '#time': 'time',
            '#description': 'description'
        },
        ExpressionAttributeValues: {
            ':date': { S: updatedEvent.date },
            ':time': { S: updatedEvent.time },
            ':description': { S: updatedEvent.description }
        }
    };
    await dynamoDBClient.send(new UpdateItemCommand(params));
}
