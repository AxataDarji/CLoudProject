import { DynamoDBClient, ScanCommand } from '@aws-sdk/client-dynamodb';
import { SNSClient, PublishCommand } from '@aws-sdk/client-sns';
import { SQSClient, SendMessageCommand } from '@aws-sdk/client-sqs';

const dynamodb = new DynamoDBClient({ region: 'us-east-1' });
const sns = new SNSClient({ region: 'us-east-1' });
const sqs = new SQSClient({ region: 'us-east-1' });

const TABLE_NAME = 'Events';
const DATE_COLUMN = 'date';
const DESCRIPTION_COLUMN = 'description';
const TIME_COLUMN = 'time';
const SNS_TOPIC_ARN = 'arn:aws:sns:us-east-1:698915160078:EventNotification';
const SQS_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/698915160078/EventsQueue';

export const handler = async (event) => {
    // Get the current date in YYYY-MM-DD format
    const currentDate = new Date().toISOString().split('T')[0];

    // Scan parameters for DynamoDB with Expression Attribute Names
    const params = {
        TableName: TABLE_NAME,
        FilterExpression: '#date = :current_date',
        ExpressionAttributeNames: {
            '#date': 'date',  // Using EAN to avoid reserved keyword issue
        },
        ExpressionAttributeValues: {
            ':current_date': { S: currentDate },
        },
    };

    try {
        // Scan DynamoDB table for items with the current date
        const data = await dynamodb.send(new ScanCommand(params));
        const items = data.Items;

        // Iterate over each item and send notifications
        for (const item of items) {
            const description = item[DESCRIPTION_COLUMN]?.S;
            const time = item[TIME_COLUMN]?.S;

            // Construct detailed message content
            let message = `Event Description: ${description}\n`;

            message += `\nHey buddy,\n\n`
                     + `How are you doing today? You are strong buddy and you can do anything!!\n`
                     + `Just a reminder that today you have Event: ${description}`;
                     
            // Add time to message if it exists
            if (time && time.trim() !== '') {
                message += ` at: ${time}\n`;
            }

            message+=`\n\nDo not forget about this and keep rocking!!\nHave a fantastic day!!`;
            // Publish message to SNS
            await sns.send(new PublishCommand({
                TopicArn: SNS_TOPIC_ARN,
                Subject: `Event Notification for ${currentDate}`,
                Message: message,
            }));

            // Send message to SQS
            await sqs.send(new SendMessageCommand({
                QueueUrl: SQS_QUEUE_URL,
                MessageBody: message,
            }));
        }

        // Return success response
        return {
            statusCode: 200,
            body: `Sent ${items.length} notifications`,
        };
    } catch (error) {
        console.error('Error sending notifications:', error);

        // Return error response
        return {
            statusCode: 500,
            body: `Failed to send notifications: ${error.message}`,
        };
    }
};
