import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1", // Change the region to match your DynamoDB region
});

const mainTableName = 'Events';

export const handler = async (event) => {
    try {
        console.log("Input is: ", event);

        // Check if event.body exists and parse it if it's a string
        const body = event.body ? (typeof event.body === 'string' ? JSON.parse(event.body) : event.body) : event;

        // Generate eventId using current timestamp
        const eventId = Date.now().toString();

        // Add item to main table
        const item = {
            eventId: { S: eventId },
            date: { S: body.date },
            time: { S: body.time },
            description: { S: body.description }
        };
        await addItemToMainTable(item);

        console.log("Item added successfully");

        // Return success response with CORS headers
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*", // Allow all origins
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: 'Item added successfully.', eventId: eventId }),
        };
    } catch (error) {
        console.error("Error occurred which is: ", error);
        // Return error with CORS headers
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*", // Allow all origins
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: 'Error adding item to DB', error: error.message }),
        };
    }
};

async function addItemToMainTable(item) {
    const params = {
        TableName: mainTableName,
        Item: item,
        ConditionExpression: 'attribute_not_exists(eventId)' // Ensure eventId is unique
    };
    await dynamoDBClient.send(new PutItemCommand(params));
}
