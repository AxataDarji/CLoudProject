import { DynamoDBClient, QueryCommand } from "@aws-sdk/client-dynamodb";

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1", // Change the region to match your DynamoDB region
});

const tableName = 'Users'; // Replace 'UserTable' with your DynamoDB table name

export const handler = async (event) => {
    try {
        console.log("Input is: ", event);

        // Extract username and password from the event object
        const { username, password } = event;

        // Retrieve user details from DynamoDB
        const user = await getUserByUsername(username);

        // Check if user exists and password matches
        if (user && user.Items.length === 1 && user.Items[0].password.S === password) {
            console.log("User login successful");
            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'User login successful.' }),
            };
        } else {
            console.log("Invalid username or password");
            return {
                statusCode: 401,
                body: JSON.stringify({ message: 'Invalid username or password.' }),
            };
        }
    } catch (error) {
        console.error("Error occurred which is: ", error);
        // Return error
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error logging in user', error: error.message }),
        };
    }
};

async function getUserByUsername(username) {
    const params = {
        TableName: tableName,
        KeyConditionExpression: "username = :username",
        ExpressionAttributeValues: {
            ":username": { S: username }
        }
    };
    return dynamoDBClient.send(new QueryCommand(params));
}
