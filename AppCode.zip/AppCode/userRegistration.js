import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1", // Change the region to match your DynamoDB region
});

const tableName = 'Users'; // Replace 'UserTable' with your DynamoDB table name

export const handler = async (event) => {
    try {
        console.log("Input is: ", event);

        // Extract username and password from the event object
        const { username, password } = event;

        // Generate unique userId

        // Register user in DynamoDB
        await registerUser( username, password);

        console.log("User registered successfully");

        // Return success response with the generated userId
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'User registered successfully.', username: username }),
        };
    } catch (error) {
        console.error("Error occurred which is: ", error);
        // Return error
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error registering user', error: error.message }),
        };
    }
};

async function registerUser(username, password) {
    const params = {
        TableName: tableName,
        Item: {
            username: { S: username },
            password: { S: password } // Note: This is not secure, use hashing for passwords
        }
    };
    await dynamoDBClient.send(new PutItemCommand(params));
}
